package com.jah.mylibrary;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnAllBooks, btnAlreadyRead, btnWanttoRead, btnCurrentlyReading, btnFav, btnAbout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();

        // wire the click for the button
        btnAllBooks.setOnClickListener( new View.OnClickListener(){

            public void onClick(View v){
                // send the user to the AllBooksActivity
                Intent intent = new Intent(MainActivity.this, AllBooksActivity.class);
                startActivity(intent);
            }
        });

        // wire the button click for AlReady Read
        btnAlreadyRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // send the user to the AlreadyReadBookActivity
                Intent intent = new Intent(MainActivity.this, AlreadyReadBookActivity.class);
                startActivity(intent);
            }
        });

        // wire the Favorites button
        btnFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int size = Utils.getInstance(MainActivity.this).getFavoriteBooks().size();
                if(size == 0){
                    Toast.makeText(MainActivity.this, "List Empty", Toast.LENGTH_SHORT).show();
                }else{
                    // send the user to the FavoritesActivity
                    Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
                    startActivity(intent);
                }

            }
        });


        // My Wish List Click button
        btnWanttoRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int size = Utils.getInstance(MainActivity.this).getWantToReadBooks().size();
                if(size == 0){
                    Toast.makeText(MainActivity.this, "List Empty", Toast.LENGTH_SHORT).show();
                }else {
                    // send the user to the WantToReadActivity
                    Intent intent = new Intent(MainActivity.this, WantToReadActivity.class);
                    startActivity(intent);
                }

            }
        });

        btnCurrentlyReading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int size = Utils.getInstance(MainActivity.this).getCurrentlyReadingBooks().size();
                if(size == 0){
                    Toast.makeText(MainActivity.this, "List Empty", Toast.LENGTH_SHORT).show();
                }else {
                    // send the user to the WantToReadActivity
                    Intent intent = new Intent(MainActivity.this, CurrentlyReadingActivity.class);
                    startActivity(intent);
                }
            }
        });

        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder build = new AlertDialog.Builder(MainActivity.this);
                build.setTitle(getString(R.string.app_name));
                build.setMessage("Designed and developed by Jahangir Ismail aka Dr.Scooby");
                build.setPositiveButton("Visit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MainActivity.this, WebsiteActivity.class);
                        startActivity(intent);

                    }
                });
                build.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                build.create().show();
            }
        }

        );
    }

    // init the buttons
    private void initViews() {
        btnAllBooks = findViewById(R.id.btnAllBooks);
        btnAlreadyRead = findViewById(R.id.btnAlreadyRead);
        btnWanttoRead = findViewById(R.id.btnWantToRead); // My Wish List
        btnCurrentlyReading = findViewById(R.id.btnCurrentlyReadin);
        btnFav = findViewById(R.id.btnFavorite);
        btnAbout = findViewById(R.id.btnAbout);
    }
}