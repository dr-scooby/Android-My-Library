package com.jah.mylibrary;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.TransitionManager;

import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class BookRecViewAdapter extends RecyclerView.Adapter<BookRecViewAdapter.ViewHolder>{

    private static final String TAG = "BookRecViewAdapter";

    private ArrayList<Book> books = new ArrayList<>();
    private Context mContext; // used for Glide
    private String parentActivity;




    public BookRecViewAdapter(Context con){
        this.mContext = con;
    }


    public BookRecViewAdapter(Context con, String parentActivity){
        this.mContext = con;
        this.parentActivity = parentActivity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_book, parent, false);
        ViewHolder viewholder = new ViewHolder(view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Log.d(TAG, "onBindViewHolder: Called");
        // get book Title, and display
        holder.txtBookTitle.setText(books.get(position).getTitle());
        // get the book Image url and display
        Glide.with(mContext).asBitmap().load(books.get(position).getImageurl()).into(holder.imgBook);

        // user clicks on the card = Book, and we send the user to the
        // Book info = BookActivity
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(mContext, books.get(position).getTitle() + " Selected", Toast.LENGTH_SHORT).show();
                // navigate the user to the BookActivity
                Intent intent = new Intent(mContext, BookActivity.class);
                intent.putExtra("bookId", books.get(position).getId()); // pass the Book Object to the BookActivity
                mContext.startActivity(intent);
            }
        });

        holder.txtAuthor.setText(books.get(position).getAuthor());
        holder.txtDescription.setText(books.get(position).getShortdescr());


        // Expand the book view
        if(books.get(position).isExpanded()){
            TransitionManager.beginDelayedTransition(holder.parent);
            holder.expandedRelLayout.setVisibility(View.VISIBLE);
            holder.downArrow.setVisibility(View.GONE);

            if(parentActivity.equals("allbooks")){
                holder.btnDelete.setVisibility(View.GONE);
            }else if(parentActivity.equals("alreadyRead")){
                holder.btnDelete.setVisibility(View.VISIBLE);
                holder.btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setMessage("Are you sure you want to delete " + books.get(position).getTitle() + " ?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                    if(Utils.getInstance(mContext).removeFromAlreadyRead(books.get(position))){
                                        Toast.makeText(mContext, "Removed " , Toast.LENGTH_SHORT).show();
                                        notifyDataSetChanged();

                                    }
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // don't do anything
                            }
                        });

                        builder.create().show();
                    }
                });


            }else if(parentActivity.equals("wantToRead")){

                holder.btnDelete.setVisibility(View.VISIBLE);
                holder.btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setMessage("Are you sure you want to delete " + books.get(position).getTitle() + " ?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if(Utils.getInstance(mContext).removeFromToWantToReadBooks(books.get(position))){
                                    Toast.makeText(mContext, "Removed " , Toast.LENGTH_SHORT).show();
                                    notifyDataSetChanged();

                                }
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // don't do anything
                            }
                        });

                        builder.create().show();
                    }
                });

            }else if(parentActivity.equals("currentlyReading")){

                holder.btnDelete.setVisibility(View.VISIBLE);
                holder.btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setMessage("Are you sure you want to delete " + books.get(position).getTitle() + " ?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if(Utils.getInstance(mContext).removeFromCurrentlyReadingBooks(books.get(position))){
                                    Toast.makeText(mContext, "Removed " , Toast.LENGTH_SHORT).show();
                                    notifyDataSetChanged();

                                }
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // don't do anything
                            }
                        });

                        builder.create().show();
                    }
                });

            }else if(parentActivity.equals("Favorites")){
                // removeFromFavoriteBooks
                holder.btnDelete.setVisibility(View.VISIBLE);
                holder.btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setMessage("Are you sure you want to delete " + books.get(position).getTitle() + " ?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if(Utils.getInstance(mContext).removeFromFavoriteBooks(books.get(position))){
                                    Toast.makeText(mContext, "Removed " , Toast.LENGTH_SHORT).show();
                                    notifyDataSetChanged();

                                }
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // don't do anything
                            }
                        });

                        builder.create().show();
                    }
                });

            }
        }else{
            TransitionManager.beginDelayedTransition(holder.parent);
            holder.expandedRelLayout.setVisibility(View.GONE);
            holder.downArrow.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public void setBooks(ArrayList<Book> books){
        this.books = books;
        notifyDataSetChanged(); // refresh, data changed
    }

    //-- Inner Class ViewHolder
    public class ViewHolder extends RecyclerView.ViewHolder{

        private CardView parent; // parent of the card
        private ImageView imgBook;
        private TextView txtBookTitle;

        // up and down arrow buttons
        private ImageView downArrow, upArrow;

        private RelativeLayout expandedRelLayout;
        private TextView txtAuthor, txtDescription;

        private TextView btnDelete;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // init UI Elements
            parent = itemView.findViewById(R.id.parent1);
            imgBook = itemView.findViewById(R.id.imgBook);
            txtBookTitle = itemView.findViewById(R.id.txtBookTitle);

            downArrow = itemView.findViewById(R.id.btnDownArrow);
            upArrow = itemView.findViewById(R.id.btnUpArrow);

            expandedRelLayout = itemView.findViewById(R.id.expandedRelLayout);

            txtAuthor = itemView.findViewById(R.id.txtAuthor);
            txtDescription = itemView.findViewById(R.id.txtShortDescription);

            btnDelete = itemView.findViewById(R.id.btnDelete);

            downArrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Book book = books.get(getAdapterPosition());
                    book.setExpanded(!book.isExpanded()); // inverting the boolean
                    /*
                     same as saying: boolean b = book.isExpanded()
                     !b
                     */

                    // update RecyclerViewAdapter
                    notifyItemChanged(getAdapterPosition());
                }
            });

            upArrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Book book = books.get(getAdapterPosition());
                    book.setExpanded(!book.isExpanded()); // inverting the boolean
                    // update RecyclerViewAdapter
                    notifyItemChanged(getAdapterPosition());
                }
            });

        }
    }
}
