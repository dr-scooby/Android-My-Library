package com.jah.mylibrary;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

// the Database
// singleton class
public class Utils {

    private static final String ALL_BOOKS_KEY = "all_books";
    private static final String ALREADY_READ_BOOKS = "already_read_books";
    private static final String WANT_TO_READ = "want_to_read";
    private static final String CURRENTLY_READING = "currently_reading";
    private static final String FAVS = "favs";

    private static Utils utls;

    private SharedPreferences sharedpreferences;

    private static ArrayList<Book> allbooks;
    private static ArrayList<Book> allreadyReadBooks;
    private static ArrayList<Book> wantToReadBooks;
    private static ArrayList<Book> currentlyReadingBooks;
    private static ArrayList<Book> favoriteBooks;


    private Utils(){



        if( getAllbooks() == null){
            initData();
        }

//        if( allbooks == null){
//            allbooks = new ArrayList<>();
//            initData();
//        }

//        if(allreadyReadBooks == null){
//            allreadyReadBooks = new ArrayList<>();
//        }

        SharedPreferences.Editor edi = sharedpreferences.edit();
        Gson gs = new Gson();

        if( getAllreadyReadBooks() == null){
            edi.putString(ALREADY_READ_BOOKS, gs.toJson(new ArrayList<Book>()));
            edi.commit();
        }

//        if(wantToReadBooks == null){
//            wantToReadBooks = new ArrayList<>();
//        }

        if(getWantToReadBooks() == null){
            edi.putString(WANT_TO_READ, gs.toJson(new ArrayList<Book>()));
            edi.commit();
        }

//        if(currentlyReadingBooks == null){
//            currentlyReadingBooks = new ArrayList<>();
//        }
        if( getCurrentlyReadingBooks() == null){
            edi.putString(CURRENTLY_READING, gs.toJson(new ArrayList<Book>()));
            edi.commit();
        }

//        if(favoriteBooks == null){
//            favoriteBooks = new ArrayList<>();
//        }

        if(getFavoriteBooks() == null){
            edi.putString(FAVS, gs.toJson(new ArrayList<Book>()));
            edi.commit();
        }

    }

    private Utils(Context c){
        //this();
        sharedpreferences = c.getSharedPreferences("alternate_db", Context.MODE_PRIVATE);

        if( getAllbooks() == null){
            initData();
        }

        SharedPreferences.Editor editor = sharedpreferences.edit();
        Gson gson = new Gson();

        if( getCurrentlyReadingBooks() == null){
            editor.putString(CURRENTLY_READING, gson.toJson(new ArrayList<Book>()));
            editor.commit();
        }

        if(getAllreadyReadBooks() == null){
            editor.putString(ALREADY_READ_BOOKS, gson.toJson(new ArrayList<Book>()));
            editor.commit();
        }

        if(getWantToReadBooks() == null){
            editor.putString(WANT_TO_READ, gson.toJson(new ArrayList<Book>()));
            editor.commit();
        }

        if(getFavoriteBooks() == null){
            editor.putString(FAVS, gson.toJson(new ArrayList<Book>()));
            editor.commit();
        }
    }


    private void initData(){

        ArrayList<Book> books = new ArrayList<>();


        String description = "";

        String story = "Goldfinger is the seventh novel in Ian Fleming's James Bond series. Written in January and February 1958, it was first published in the UK by Jonathan Cape on 23 March 1959. The story centres on the investigation by the British Secret Service operative James Bond into the gold smuggling activities of Auric Goldfinger, who is also suspected by MI6 of being connected to SMERSH, the Soviet counter-intelligence organisation. As well as establishing the background to the smuggling operation, Bond uncovers a much larger plot: Goldfinger plans to steal the gold reserves of the United States from Fort Knox.\n" +
                "\n" +
                "Fleming developed the James Bond character in Goldfinger, presenting him as a more complex individual than in the previous novels, and bringing out a theme of Bond as a St George figure. This theme is echoed by the fact that it is a British agent sorting out an American problem. In common with his other Bond stories, Fleming used the names of people he knew, or knew of, throughout his story, including the book's eponymous villain, who was named after the architect Ernő Goldfinger. On learning of the use of his name, Goldfinger threatened to sue, before the matter was settled out of court. Auric Goldfinger is obsessed by gold and—to Bond's eye—a gauche individual with unusual appetites; Fleming probably based the character on the American gold tycoon Charles W. Engelhard Jr. Fleming also used his own experiences within the book; the round of golf played with Goldfinger was based on a 1957 tournament at the Berkshire Golf Club in which Fleming partnered Peter Thomson, the winner of The Open Championship.\n" +
                "\n" +
                "On its release, Goldfinger went to the top of the best-seller lists; the novel was broadly well received by the critics and was favourably compared to the works of the thriller writers H. C. McNeile and John Buchan. Goldfinger was serialised as a daily story and as a comic strip in the Daily Express, before it became the third James Bond feature film of the Eon Productions series, released in 1964 and starring Sean Connery as Bond. In 2010 Goldfinger was adapted for BBC Radio with Toby Stephens as Bond and Sir Ian McKellen as Goldfinger.";


        books.add(new Book(1, "GoldFinger", "Ian Flemming", 120, "https://www.scriptslug.com/assets/posters/_posterPageJpg/goldfinger-1964.jpg",
                "007 ", story));


        story = "After recovering from serious poisoning inflicted by the SMERSH agent Rosa Klebb (in From Russia, with Love) the MI6 agent James Bond is sent by his superior, M, on an undemanding mission to the British Colony of Jamaica. He is instructed to investigate the disappearance of Commander John Strangways, the head of MI6's Station J in Kingston, and his secretary. Bond is briefed that Strangways had been investigating the activities of Doctor Julius No, a reclusive Chinese-German who lives on the fictional island of Crab Key and runs a guano mine. The island has a colony of roseate spoonbills at one end while local rumour is that a vicious dragon also lives there. The spoonbills are protected by the American National Audubon Society, two of whose representatives died when their plane crashed on No's airstrip.\n" +
                "\n" +
                "On his arrival in Jamaica, Bond soon realises that he is being watched. His hotel room is searched, a basket of poisoned fruit is delivered to the room—supposedly a gift from the colonial governor—and a deadly centipede is placed in his bed while he is sleeping. With the help of an old friend, Quarrel, Bond surreptitiously visits Crab Key to establish whether there is a connection between No and the disappearance of the MI6 personnel. Bond and Quarrel meet Honeychile Rider, who is there to collect valuable shells. Bond and Rider are captured by No's men after Quarrel is burned to death by the doctor's \"dragon\"—a flamethrowing, armoured swamp buggy designed to keep away trespassers. Bond and Rider are taken to a luxurious facility carved into the mountain.\n" +
                "\n" +
                "No tells Bond that he is working with the Russians and has built an elaborate underground facility from which he can sabotage US test missiles launched from Cape Canaveral. He had previously been a member of a Chinese tong, but after he stole a large amount of money from their treasury, he was captured by the organisation. The tong's leaders had No's hands cut off as a warning to others, and then shot him. Because No's heart was on the right side of his body, the bullet missed it and he survived.\n" +
                "\n" +
                "Interested in the ability of the human body to withstand and survive pain, No forces Bond to navigate his way through an obstacle course constructed in the facility's ventilation system. Bond is kept under observation as he suffers electric shocks, burns and an encounter with large poisonous spiders. Bond's ordeal ends in a fight with a captive giant squid, which he defeats by using improvised weapons. After his escape he encounters Rider, who had been pegged out to be eaten by crabs; they had ignored her and she managed to escape.\n" +
                "\n" +
                "Bond kills No by taking over the guano-loading machine at the docks and diverting the flow of guano to bury him alive. Bond and Rider then escape from No's complex in the \"dragon\" buggy, sail back to Jamaica and notify the colonial authorities.";

        books.add(new Book(2, "Dr. No", "Ian Flemming", 85, "https://m.media-amazon.com/images/I/91H7nJWknIL._AC_SL1500_.jpg",
                "007 ", story));

        books.add(new Book(3, "The Great Escape", "Paul Brickhill", 190, "https://www.kinolorber.com/media_cache/images/full/738329257361(no-o-card).jpg",
                "escape from German prison camp ", "WW2 allies prisoners escape from a German prison camp, based on true store"));


        description = "Plato (/ˈpleɪtoʊ/ PLAY-toe;[2] Greek: Πλάτων Plátōn; 428/427 or 424/423 – 348/347 BC) was a Greek philosopher born in Athens during the Classical period in Ancient Greece. He founded the Platonist school of thought and the Academy, the first institution of higher learning in the Western world.\n" +
                "\n" +
                "Plato is widely considered a pivotal figure in the history of Ancient Greek and Western philosophy, along with his teacher, Socrates, and his most famous student, Aristotle.[a] He has often been cited as one of the founders of Western religion and spirituality.[5] The so-called neoplatonism of philosophers, such as Plotinus and Porphyry, greatly influenced Christianity through Church Fathers such as Augustine. Alfred North Whitehead once noted: \"the safest general characterization of the European philosophical tradition is that it consists of a series of footnotes to Plato.\"[6]\n" +
                "\n" +
                "Plato was an innovator of the written dialogue and dialectic forms in philosophy. Plato is also considered the founder of Western political philosophy. His most famous contribution is the theory of Forms known by pure reason, in which Plato presents a solution to the problem of universals known as Platonism (also ambiguously called either Platonic realism or Platonic idealism). He is also the namesake of Platonic love and the Platonic solids.\n" +
                "\n" +
                "His own most decisive philosophical influences are usually thought to have been, along with Socrates, the pre-Socratics Pythagoras, Heraclitus and Parmenides, although few of his predecessors' works remain extant and much of what we know about these figures today derives from Plato himself.[b] Unlike the work of nearly all of his contemporaries, Plato's entire body of work is believed to have survived intact for over 2,400 years.[8] Although their popularity has fluctuated, Plato's works have consistently been read and studied";

        books.add(new Book(4, "Republic (Plato)", "Plato", 190, "https://www.basicbooks.com/wp-content/uploads/2017/09/9780465094097.jpg",
                "a Socratic dialogue ", description));


        description = "The Hound of the Baskervilles is the third of the four crime novels written by Sir Arthur Conan Doyle featuring the detective Sherlock Holmes. Originally serialised in The Strand Magazine from August 1901 to April 1902, it is set largely on Dartmoor in Devon in England's West Country and tells the story of an attempted murder inspired by the legend of a fearsome, diabolical hound of supernatural origin. Holmes and Watson investigate the case. This was the first appearance of Holmes since his apparent death in \"The Final Problem\", and the success of The Hound of the Baskervilles led to the character's eventual revival.";
        books.add(new Book(5, "The Hound of the Baskervilles", " Sir Arthur Conan Doyle", 300, "https://www.gutenberg.org/files/2852/2852-h/images/cover.jpg",
                "Sherlock Holmes investigates a friends murder. ", description));


        SharedPreferences.Editor edit = sharedpreferences.edit();
        // using Gson to serialize books
        Gson gson = new Gson();
        edit.putString(ALL_BOOKS_KEY, gson.toJson(books));
        edit.apply(); // the other edit.apply() uses Thread so app is not stalling, hanging



    }


    public static  Utils getInstance(){
        if( utls != null){
            return utls;
        }else{
            utls = new Utils();
            return utls;
        }

        //return utls;
    }

    public static Utils getInstance(Context con){
        if( utls != null){
            return utls;
        }else{
            utls = new Utils(con);
            return utls;
        }
    }


    public  ArrayList<Book> getAllbooks() {
        // de-serialize from the Gson
        Gson gson = new Gson();
        Type ty = new TypeToken<ArrayList<Book>>(){}.getType();
        ArrayList<Book> books = gson.fromJson(sharedpreferences.getString(ALL_BOOKS_KEY, null), ty);
        //return allbooks;
        return books;
    }

    public static void setAllbooks(ArrayList<Book> allbooks) {
        Utils.allbooks = allbooks;
    }

    public  ArrayList<Book> getAllreadyReadBooks() {
        Gson gs = new Gson();
        Type t = new TypeToken<ArrayList<Book>>(){}.getType();
        ArrayList<Book> books = gs.fromJson(sharedpreferences.getString(ALREADY_READ_BOOKS, null), t);
        //return allreadyReadBooks;
        return books;
    }

    public static void setAllreadyReadBooks(ArrayList<Book> allreadyReadBooks) {
        Utils.allreadyReadBooks = allreadyReadBooks;
    }

    public  ArrayList<Book> getWantToReadBooks() {
        Gson gs = new Gson();
        Type t = new TypeToken<ArrayList<Book>>(){}.getType();
        ArrayList<Book> books = gs.fromJson(sharedpreferences.getString(WANT_TO_READ, null), t);

        return books;
        //return wantToReadBooks;
    }

    public static void setWantToReadBooks(ArrayList<Book> wantToReadBooks) {
        Utils.wantToReadBooks = wantToReadBooks;
    }

    public  ArrayList<Book> getCurrentlyReadingBooks() {
        Gson gs = new Gson();
        Type t = new TypeToken<ArrayList<Book>>(){}.getType();
        ArrayList<Book> books = gs.fromJson(sharedpreferences.getString(CURRENTLY_READING, null), t);

        return books;
        //return currentlyReadingBooks;
    }

    public static void setCurrentlyReadingBooks(ArrayList<Book> currentlyReadingBooks) {
        Utils.currentlyReadingBooks = currentlyReadingBooks;
    }


    public  ArrayList<Book> getFavoriteBooks() {
        Gson gs = new Gson();
        Type t = new TypeToken<ArrayList<Book>>(){}.getType();
        ArrayList<Book> books = gs.fromJson(sharedpreferences.getString(FAVS, null), t);

        return books;

        //return favoriteBooks;
    }

    public static void setFavoriteBooks(ArrayList<Book> favoriteBooks) {
        Utils.favoriteBooks = favoriteBooks;
    }

    // get the Book by book id
    public Book getBookID(int id){
        ArrayList<Book> books = getAllbooks();
        if( books != null){
            for (Book b: books){
                if(b.getId() == id){
                    return b;
                }
            }
        }

        // if no book found, return null
        return null;
    }

    // add Book to Already Read
    public boolean addToAlreadyRead(Book b){
        // get ArrayList
        ArrayList<Book> books = getAllreadyReadBooks();
        if(books != null){ // if not null
            if(books.add(b)){ // add Book to ArrayList
                // using Gson to serialize object
                Gson gs = new Gson();
                SharedPreferences.Editor edit = sharedpreferences.edit();
                edit.remove(ALREADY_READ_BOOKS); // remove
                edit.putString(ALREADY_READ_BOOKS, gs.toJson(books)); // add new data set
                edit.commit(); // commit
                return true;

            }
        }
        //return allreadyReadBooks.add(b);

        return false;
    }

    // add Book to Favorites
    public boolean addToFavoriteBooks(Book b){
        // get ArrayList
        ArrayList<Book> books = getFavoriteBooks();
        if(books != null){ // if not null
            if(books.add(b)){ // add Book to ArrayList
                // using Gson to serialize object
                Gson gs = new Gson();
                SharedPreferences.Editor edit = sharedpreferences.edit();
                edit.remove(FAVS); // remove
                edit.putString(FAVS, gs.toJson(books)); // add new data set
                edit.commit(); // commit
                return true;

            }
        }

        return false;
        //return favoriteBooks.add(b);
    }

    // add Book to Want To Read list
    public boolean addToWantToReadBooks(Book b){
        // get ArrayList
        ArrayList<Book> books = getWantToReadBooks();
        if(books != null){ // if not null
            if(books.add(b)){ // add Book to ArrayList
                // using Gson to serialize object
                Gson gs = new Gson();
                SharedPreferences.Editor edit = sharedpreferences.edit();
                edit.remove(WANT_TO_READ); // remove
                edit.putString(WANT_TO_READ, gs.toJson(books)); // add new data set
                edit.commit(); // commit
                return true;

            }
        }

        return false;
        //return wantToReadBooks.add(b);
    }

    // add book to CurrentlyReading
    public boolean addToCurrentlyReadingBooks(Book b){
        // get ArrayList
        ArrayList<Book> books = getCurrentlyReadingBooks();
        if(books != null){ // if not null
            if(books.add(b)){ // add Book to ArrayList
                // using Gson to serialize object
                Gson gs = new Gson();
                SharedPreferences.Editor edit = sharedpreferences.edit();
                edit.remove(CURRENTLY_READING); // remove
                edit.putString(CURRENTLY_READING, gs.toJson(books)); // add new data set
                edit.commit(); // commit
                return true;

            }
        }

        return false;
        //return currentlyReadingBooks.add(b);
    }

    // remove book from already read
    public boolean removeFromAlreadyRead(Book book){
        ArrayList<Book> books = getAllreadyReadBooks();
        if(books != null){
            // can't use books.remove(book) - the reference is different, doesn't work
            // need to use:
            for(Book b: books){
                if(b.getId() == book.getId()){ // check book id is same
                   if( books.remove(b) ){ // try to remove
                       // use Gson to serialize
                       Gson gs = new Gson();
                       SharedPreferences.Editor edi = sharedpreferences.edit();
                       edi.remove(ALREADY_READ_BOOKS); // remove the data set
                       edi.putString(ALREADY_READ_BOOKS, gs.toJson(books)); // add new data set
                       edi.commit(); // commit
                       return true;
                   }
                }
            }
        }
        return false;

        //return allreadyReadBooks.remove(book);

    }

    // remove book from want to read
    public boolean removeFromToWantToReadBooks(Book book){
        ArrayList<Book> books = getWantToReadBooks();
        if(books != null){
            // can't use books.remove(book) - the reference is different, doesn't work
            // need to use:
            for(Book b: books){
                if(b.getId() == book.getId()){ // check book id is same
                    if( books.remove(b) ){ // try to remove
                        // use Gson to serialize
                        Gson gs = new Gson();
                        SharedPreferences.Editor edi = sharedpreferences.edit();
                        edi.remove(WANT_TO_READ); // remove the data set
                        edi.putString(WANT_TO_READ, gs.toJson(books)); // add new data set
                        edi.commit(); // commit
                        return true;
                    }
                }
            }
        }
        return false;
        //eturn wantToReadBooks.remove(b);
    }

    // remove book from currently reading
    public boolean removeFromCurrentlyReadingBooks(Book book){
        ArrayList<Book> books = getCurrentlyReadingBooks();
        if(books != null){
            // can't use books.remove(book) - the reference is different, doesn't work
            // need to use:
            for(Book b: books){
                if(b.getId() == book.getId()){ // check book id is same
                    if( books.remove(b) ){ // try to remove
                        // use Gson to serialize
                        Gson gs = new Gson();
                        SharedPreferences.Editor edi = sharedpreferences.edit();
                        edi.remove(CURRENTLY_READING); // remove the data set
                        edi.putString(CURRENTLY_READING, gs.toJson(books)); // add new data set
                        edi.commit(); // commit
                        return true;
                    }
                }
            }
        }
        return false;

        //return currentlyReadingBooks.remove(b);
    }

    public boolean removeFromFavoriteBooks(Book book){
        ArrayList<Book> books = getFavoriteBooks();
        if(books != null){
            // can't use books.remove(book) - the reference is different, doesn't work
            // need to use:
            for(Book b: books){
                if(b.getId() == book.getId()){ // check book id is same
                    if( books.remove(b) ){ // try to remove
                        // use Gson to serialize
                        Gson gs = new Gson();
                        SharedPreferences.Editor edi = sharedpreferences.edit();
                        edi.remove(FAVS); // remove the data set
                        edi.putString(FAVS, gs.toJson(books)); // add new data set
                        edi.commit(); // commit
                        return true;
                    }
                }
            }
        }
        return false;
       // return favoriteBooks.remove(b);
    }
}
