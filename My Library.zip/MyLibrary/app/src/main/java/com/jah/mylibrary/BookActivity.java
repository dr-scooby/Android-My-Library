package com.jah.mylibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class BookActivity extends AppCompatActivity {

    private TextView txtBookTitle, txtAuthor, txtPages, txtDescription;
    private Button btnAddToWantToRead, btnAddToAlreadyRead, btnAddToCurrentlyReading, btnAddToFavorite;
    private ImageView bookImage;

    private boolean alreadyexists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        initViews(); // init UI Elements

        String story = "Goldfinger is the seventh novel in Ian Fleming's James Bond series. Written in January and February 1958, it was first published in the UK by Jonathan Cape on 23 March 1959. The story centres on the investigation by the British Secret Service operative James Bond into the gold smuggling activities of Auric Goldfinger, who is also suspected by MI6 of being connected to SMERSH, the Soviet counter-intelligence organisation. As well as establishing the background to the smuggling operation, Bond uncovers a much larger plot: Goldfinger plans to steal the gold reserves of the United States from Fort Knox.\n" +
                "\n" +
                "Fleming developed the James Bond character in Goldfinger, presenting him as a more complex individual than in the previous novels, and bringing out a theme of Bond as a St George figure. This theme is echoed by the fact that it is a British agent sorting out an American problem. In common with his other Bond stories, Fleming used the names of people he knew, or knew of, throughout his story, including the book's eponymous villain, who was named after the architect Ernő Goldfinger. On learning of the use of his name, Goldfinger threatened to sue, before the matter was settled out of court. Auric Goldfinger is obsessed by gold and—to Bond's eye—a gauche individual with unusual appetites; Fleming probably based the character on the American gold tycoon Charles W. Engelhard Jr. Fleming also used his own experiences within the book; the round of golf played with Goldfinger was based on a 1957 tournament at the Berkshire Golf Club in which Fleming partnered Peter Thomson, the winner of The Open Championship.\n" +
                "\n" +
                "On its release, Goldfinger went to the top of the best-seller lists; the novel was broadly well received by the critics and was favourably compared to the works of the thriller writers H. C. McNeile and John Buchan. Goldfinger was serialised as a daily story and as a comic strip in the Daily Express, before it became the third James Bond feature film of the Eon Productions series, released in 1964 and starring Sean Connery as Bond. In 2010 Goldfinger was adapted for BBC Radio with Toby Stephens as Bond and Sir Ian McKellen as Goldfinger.";

        // testing only
        Book book = new  Book(1, "GoldFinger", "Ian Flemming", 120, "https://www.scriptslug.com/assets/posters/_posterPageJpg/goldfinger-1964.jpg",
                "007 ", story);

        Intent intent = getIntent();
        if(intent != null){
            int bookid = intent.getIntExtra("bookId", -1); // using -1 ?
            if(bookid != -1){
                Book incomingbook = Utils.getInstance(this).getBookID(bookid);
                if(incomingbook != null){
                    setData(incomingbook);
                    handleAlreadyRead(incomingbook);
                    handleWantToReadBooks(incomingbook);
                    handleCurrentlyReadingBooks(incomingbook);
                    handleFavorites(incomingbook);
                }else{
                    // if null, put a test book
                    setData(book);
                }


            }
        }

    }// end onCreate

    // handle the currently reading books
    private void handleCurrentlyReadingBooks(Book incoming){
        // get the Already Read Books listing
        ArrayList<Book> currentlyReading = Utils.getInstance(this).getCurrentlyReadingBooks();

        boolean alreadyexists_reading = false;
        // check if book already exists in list-DB
        for( Book b: currentlyReading){
            if(b.getId() == incoming.getId()){
                alreadyexists_reading = true;
            }
        }// end for

        if(alreadyexists_reading){
            btnAddToCurrentlyReading.setEnabled(false);
        }else{
            btnAddToCurrentlyReading.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(Utils.getInstance(BookActivity.this).addToCurrentlyReadingBooks(incoming)){
                        Toast.makeText(BookActivity.this, "Success, Book Added to Currently Reading list", Toast.LENGTH_LONG).show();
                        btnAddToCurrentlyReading.setEnabled(false);
                    }else{
                        Toast.makeText(BookActivity.this, "Something Wrong occurred", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

    }

    // handle the Want to Read books, same as wish list
    private void handleWantToReadBooks(Book incoming){
        // get the Already Read Books listing
        ArrayList<Book> wantToReadBooksList = Utils.getInstance(this).getWantToReadBooks();

        boolean alreadyexists_want = false;
        // check if book already exists in list-DB
        for( Book b: wantToReadBooksList){
            if(b.getId() == incoming.getId()){
                alreadyexists_want = true;
            }
        }// end for

        if(alreadyexists_want){
            btnAddToWantToRead.setEnabled(false);
        }else{
            btnAddToWantToRead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(Utils.getInstance(BookActivity.this).addToWantToReadBooks(incoming)){
                        Toast.makeText(BookActivity.this, "Success, Book Added to Already Read", Toast.LENGTH_LONG).show();
                        btnAddToWantToRead.setEnabled(false);
                    }else{
                        Toast.makeText(BookActivity.this, "Something Wrong occurred", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

    }

    // handle favorite books
    private void handleFavorites(Book incoming){
        ArrayList<Book> favs = Utils.getInstance(this).getFavoriteBooks();
        boolean favs_exist = false;

        for( Book b: favs){
            if(b.getId() == incoming.getId()){
                favs_exist = true;
            }
        }

        if(favs_exist){
            btnAddToFavorite.setEnabled(false);
        }else{
            btnAddToFavorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(Utils.getInstance(BookActivity.this).addToFavoriteBooks(incoming)){
                        Toast.makeText(BookActivity.this, "Success, Added to Favorites", Toast.LENGTH_LONG).show();
                        btnAddToFavorite.setEnabled(false);
                    }else{
                        Toast.makeText(BookActivity.this, "Failed to add to Favorites", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // Add the book to the all ready read
    // if the book is already added to read disable button
    private void handleAlreadyRead(Book incoming){
        // get the Already Read Books listing
        ArrayList<Book> alreadyReadBooks = Utils.getInstance(this).getAllreadyReadBooks();

        alreadyexists = false;
        // check if book already exists in list-DB
        for( Book b: alreadyReadBooks){
            if(b.getId() == incoming.getId()){
                alreadyexists = true;
            }
        }// end for

        if(alreadyexists){
            btnAddToAlreadyRead.setEnabled(false);
        }else{
            btnAddToAlreadyRead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(Utils.getInstance(BookActivity.this).addToAlreadyRead(incoming)){
                        Toast.makeText(BookActivity.this, "Success, Book Added to Already Read", Toast.LENGTH_LONG).show();
                        btnAddToAlreadyRead.setEnabled(false);
                    }else{
                        Toast.makeText(BookActivity.this, "Something Wrong occurred", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }
    }

    // set Book info, show the book info
    private void setData(Book book){

        txtBookTitle.setText(book.getTitle());
        txtAuthor.setText(book.getAuthor());
        txtPages.setText( String.valueOf(  book.getPages() ));
        txtDescription.setText(book.getLongdescr());
        Glide.with(this).asBitmap().load(book.getImageurl()).into(bookImage);
    }


    // init the UI Elements
    private void initViews(){
        txtBookTitle = findViewById(R.id.txtBookTitleAB);
        txtAuthor = findViewById(R.id.txtAuthorAB);
        txtPages = findViewById(R.id.txtPagesAB);
        txtDescription = findViewById(R.id.txtLongDescriptionAB);

        btnAddToWantToRead = findViewById(R.id.btnWishToReadAB);
        btnAddToAlreadyRead = findViewById(R.id.btnAlreadyReadAB);
        btnAddToCurrentlyReading = findViewById(R.id.btnAddToCurrentlyReadingAB);
        btnAddToFavorite = findViewById(R.id.btnAddToFavoritesAB);

        bookImage = findViewById(R.id.imageViewAB);


    }


}