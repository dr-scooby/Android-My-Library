package com.jah.mylibrary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class AlreadyReadBookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_already_read_book);

        RecyclerView recyclerView = findViewById(R.id.bookRecView);

        // re-use the BookRecViewAdapter
        BookRecViewAdapter adapter = new BookRecViewAdapter(this, "alreadyRead");
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter.setBooks(Utils.getInstance(this).getAllreadyReadBooks());
        int size = Utils.getInstance(this).getAllreadyReadBooks().size();
        if(size == 0){
            Toast.makeText(this, "Nothing in list", Toast.LENGTH_SHORT).show();
        }
    }

    // handle the back button pressed - this is the Android back button system
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, MainActivity.class);
        // setFlags clears the back button history, using 2 flags:
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }
}