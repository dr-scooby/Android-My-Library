package com.jah.mylibrary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

// Want To Read same as Wish List
public class WantToReadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_want_to_read);

        RecyclerView recview = findViewById(R.id.wantToReadRecView);
        // re-use the BookRecViewAdapter
        BookRecViewAdapter adapter = new BookRecViewAdapter(this, "wantToRead");
        recview.setAdapter(adapter);
        recview.setLayoutManager(new LinearLayoutManager(this));
        adapter.setBooks(Utils.getInstance(this).getWantToReadBooks());
    }

    // handle the back button pressed - this is the Android back button system
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, MainActivity.class);
        // setFlags clears the back button history, using 2 flags:
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }
}