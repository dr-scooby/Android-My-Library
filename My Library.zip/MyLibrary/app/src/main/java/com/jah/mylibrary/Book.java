package com.jah.mylibrary;

public class Book {

    private int id;
    private String title;
    private String author;
    private int pages;
    private String imageurl;
    private String shortdescr;
    private String longdescr;
    private boolean isExpanded; // used for the UI card

    public Book() {
        id = 0;
        title = "";
        author = "";
        pages = 0;
        imageurl = "";
        shortdescr = "";
        longdescr = "";
        isExpanded = false;
    }

    public Book(int id, String title, String author) {
        this();
        this.id = id;
        this.title = title;
        this.author = author;
    }

    public Book(int id, String title, String author, int pages, String imageurl, String shortdescr, String longdescr) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.pages = pages;
        this.imageurl = imageurl;
        this.shortdescr = shortdescr;
        this.longdescr = longdescr;
        isExpanded = false;
    }


    public boolean isExpanded() {
        return isExpanded;
    }

    public void setExpanded(boolean expanded) {
        isExpanded = expanded;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getShortdescr() {
        return shortdescr;
    }

    public void setShortdescr(String shortdescr) {
        this.shortdescr = shortdescr;
    }

    public String getLongdescr() {
        return longdescr;
    }

    public void setLongdescr(String longdescr) {
        this.longdescr = longdescr;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", pages=" + pages +
                ", imageurl='" + imageurl + '\'' +
                ", shortdescr='" + shortdescr + '\'' +
                ", longdescr='" + longdescr + '\'' +
                '}';
    }
}
