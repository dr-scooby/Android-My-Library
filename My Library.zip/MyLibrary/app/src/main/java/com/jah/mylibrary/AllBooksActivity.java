package com.jah.mylibrary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class AllBooksActivity extends AppCompatActivity {

    private Button homebutton;
    private RecyclerView booksRecView;
    private BookRecViewAdapter bookadapter;
    private ArrayList<Book> books;

    // -- Main Application Entry point
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_books);

        bookadapter = new BookRecViewAdapter(this, "allbooks");

        booksRecView = findViewById(R.id.allbooksRecView);
        booksRecView.setAdapter(bookadapter);
        //booksRecView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 cols
        booksRecView.setLayoutManager(new LinearLayoutManager(this)); // Linear Layout

        initData();
        initButton();
    }


    // init the Data model, hard code for now, testing
    private void initData(){
        //books = new ArrayList<>();


        bookadapter.setBooks(Utils.getInstance(this).getAllbooks());
    }


    private void initButton(){
        homebutton = findViewById(R.id.btnHome);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AllBooksActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}