package com.jah.mylibrary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

/**
 * FavoritesActivity shows all the favorites books listing
 */
public class FavoritesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        RecyclerView recview = findViewById(R.id.FavsRecView);
        // re-use the BookRecViewAdapter
        BookRecViewAdapter adapter = new BookRecViewAdapter(this, "Favorites");
        recview.setAdapter(adapter);
        recview.setLayoutManager(new LinearLayoutManager(this));
        adapter.setBooks(Utils.getInstance(this).getFavoriteBooks());


    }

    // handle the back button pressed - this is the Android back button system
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, MainActivity.class);
        // setFlags clears the back button history, using 2 flags:
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }
}