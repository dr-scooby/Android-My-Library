package com.jah.mylibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebsiteActivity extends AppCompatActivity {

    private WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_website);

        webview = findViewById(R.id.webView);
        webview.loadUrl("https://google.com"); // load the Chrome browser
        webview.setWebViewClient(new WebViewClient()); // load the browser inside the app
        webview.getSettings().setJavaScriptEnabled(true);

    }

    // handle the back button for the browser
    @Override
    public void onBackPressed() {
        if(webview.canGoBack()){
            webview.goBack();
        }else{
            super.onBackPressed();
        }

    }
}